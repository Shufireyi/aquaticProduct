CREATE PROCEDURE Aggr5Min()
  BEGIN

DROP TABLE if EXISTS untilnow_temp;
CREATE TABLE untilnow_temp
(
mintemp int ,
maxtemp int,
avgtemp double,
nums int,
recordtime datetime
);

SET @BeginTime = UNIX_TIMESTAMP("2016-08-12 14:40:00"); -- 从整点开始，便于5分钟汇聚规律
SET @EndTime = UNIX_TIMESTAMP("2016-08-26 18:00:00"); -- 到下一个月结束时间，这个时间无所谓是否是整点了

 WHILE @BeginTime < @EndTime DO
  SET @AddCmd = CONCAT(' insert into untilnow_temp
  select                       
															 
															 min(temp) as mintemp, 
                               max(temp) as maxtemp,
                               avg(temp) as avgtemp,
					              		   count(*) as nums,
															DATE_FORMAT(FROM_UNIXTIME(@BeginTime), "%Y-%m-%d %H:%i:%S") as recordtime from sensorrecord_new 
                        where type =2 and UNIX_TIMESTAMP(local_time) >= ',@BeginTime,' and UNIX_TIMESTAMP(local_time) < ',@BeginTime + 300);
  PREPARE AddCmd FROM @AddCmd;
  EXECUTE AddCmd;
  SET @BeginTime = @BeginTime + 300;  -- 5分钟的跨度相加
END WHILE;            
END;

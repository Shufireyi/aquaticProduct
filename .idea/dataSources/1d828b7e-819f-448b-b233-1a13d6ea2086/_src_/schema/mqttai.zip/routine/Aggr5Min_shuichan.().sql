CREATE PROCEDURE Aggr5Min_shuichan()
  BEGIN
declare v_minorp INTEGER DEFAULT 0;
declare v_maxorp INTEGER DEFAULT 0;
declare v_avgorp DOUBLE DEFAULT 0.0;
declare v_orpnums INTEGER DEFAULT 0;
declare v_minph int(11) DEFAULT 0;
declare v_maxph int(11) DEFAULT 0;
declare v_avgph double DEFAULT 0.0;
declare v_phnums int(11) DEFAULT 0;
declare v_minwtrtemp INTEGER(11) DEFAULT 0;
declare v_maxwtrtemp INTEGER(11) DEFAULT 0;
declare v_avgwtrtemp DOUBLE DEFAULT 0.0;
declare v_wtrtempnums INTEGER DEFAULT 0;
SET @BeginTime = UNIX_TIMESTAMP("2016-08-17 16:40:00"); -- 从整点开始，便于5分钟汇聚规律
WHILE @BeginTime < UNIX_TIMESTAMP(NOW()) DO
  select                                                    
    min(payload), max(payload), avg(payload),count(*) 
    into v_minorp, v_maxorp, v_avgorp, v_orpnums from mqtt_log 
         where topic ='orp' and UNIX_TIMESTAMP(concat(msgdate, ' ', msgtime)) >= @BeginTime and UNIX_TIMESTAMP(concat(msgdate, ' ', msgtime)) < @BeginTime + 300;
  select                                                    
		min(payload), max(payload), avg(payload),count(*) 
    into v_minph, v_maxph, v_avgph, v_phnums from mqtt_log 
         where topic ='ph' and UNIX_TIMESTAMP(concat(msgdate, ' ', msgtime)) >= @BeginTime and UNIX_TIMESTAMP(concat(msgdate, ' ', msgtime)) < @BeginTime + 300;
  select                                                    
		min(payload), max(payload), avg(payload),count(*)  
    into v_minwtrtemp, v_maxwtrtemp, v_avgwtrtemp, v_wtrtempnums from mqtt_log 
         where topic ='orp_temp' and UNIX_TIMESTAMP(concat(msgdate, ' ', msgtime)) >= @BeginTime and UNIX_TIMESTAMP(concat(msgdate, ' ', msgtime)) < @BeginTime + 300;
insert into untilnow_shuichan (minorp,maxorp,avgorp,orpnums,
		minph,maxph,avgph,phnums,
		minwtrtemp,maxwtrtemp,avgwtrtemp,wtrtempnums,
		recordtime) VALUES(
        v_minorp, v_maxorp, v_avgorp, v_orpnums,
        v_minph, v_maxph, v_avgph, v_phnums,
        v_minwtrtemp, v_maxwtrtemp, v_avgwtrtemp, v_wtrtempnums,
        DATE_FORMAT(FROM_UNIXTIME(@BeginTime), "%Y-%m-%d %H:%i:%S"));
  SET @BeginTime = @BeginTime + 300;  -- 5分钟的跨度相加
END WHILE; 
       
END;

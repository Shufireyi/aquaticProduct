CREATE PROCEDURE Aggr5Min_zigbee()
  BEGIN
declare v_minillu INTEGER DEFAULT 0;
declare v_maxillu INTEGER DEFAULT 0;
declare v_avgillu DOUBLE DEFAULT 0.0;
declare v_illunums INTEGER DEFAULT 0;
declare v_mintemp int(11) DEFAULT 0;
declare v_maxtemp int(11) DEFAULT 0;
declare v_avgtemp double DEFAULT 0.0;
declare v_tempnums int(11) DEFAULT 0;
declare v_minhumi INTEGER(11) DEFAULT 0;
declare v_maxhumi INTEGER(11) DEFAULT 0;
declare v_avghumi DOUBLE DEFAULT 0.0;
declare v_minairp INTEGER(11) DEFAULT 0;
declare v_maxairp INTEGER(11) DEFAULT 0;
declare v_avgairp DOUBLE DEFAULT 0.0;
declare v_airpnums INTEGER DEFAULT 0;
SET @BeginTime = UNIX_TIMESTAMP("2016-08-12 14:40:00"); -- 从整点开始，便于5分钟汇聚规律
WHILE @BeginTime < UNIX_TIMESTAMP(NOW()) DO
  select                                                    
        min(temp), max(temp), avg(temp), min(humi),max(humi),avg(humi),count(*) 
        into v_mintemp, v_maxtemp, v_avgtemp, v_minhumi, v_maxhumi, v_avghumi, v_tempnums from sensorrecord_new 
                where type =2 and UNIX_TIMESTAMP(local_time) >= @BeginTime and UNIX_TIMESTAMP(local_time) < @BeginTime + 300;
    select                                                    
        min(illu), 
    max(illu),
    avg(illu),
        count(*) 
        into v_minillu, v_maxillu, v_avgillu, v_illunums
            from sensorrecord_new 
                where type =4 and UNIX_TIMESTAMP(local_time) >= @BeginTime and UNIX_TIMESTAMP(local_time) < @BeginTime + 300;
  select                                                    
        min(press), 
    max(press),
    avg(press),
        count(*) 
        into v_minairp, v_maxairp, v_avgairp, v_airpnums
            from sensorrecord_new 
                where type =5 and UNIX_TIMESTAMP(local_time) >= @BeginTime and UNIX_TIMESTAMP(local_time) < @BeginTime + 300;
insert into untilnow_temp (mintemp, maxtemp,avgtemp,minhumi,maxhumi,avghumi,tempnums,
minairp,maxairp,avgairp,airpnums,
minillu,maxillu,avgillu,illunums,
recordtime) VALUES(
        v_mintemp, v_maxtemp, v_avgtemp, v_minhumi, v_maxhumi, v_avghumi, v_tempnums,
				v_minairp, v_maxairp, v_avgairp, v_airpnums,
        v_minillu, v_maxillu, v_avgillu, v_illunums,
        DATE_FORMAT(FROM_UNIXTIME(@BeginTime), "%Y-%m-%d %H:%i:%S"));
  SET @BeginTime = @BeginTime + 300;  -- 5分钟的跨度相加
END WHILE;            
END;

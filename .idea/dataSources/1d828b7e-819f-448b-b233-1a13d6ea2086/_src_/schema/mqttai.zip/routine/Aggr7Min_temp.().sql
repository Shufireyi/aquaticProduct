CREATE PROCEDURE Aggr7Min_temp()
  BEGIN
	
	DECLARE v_mintemp INTEGER(11) DEFAULT 0;
	DECLARE v_maxtemp INTEGER(11) DEFAULT 0;
	DECLARE v_avgtemp DOUBLE DEFAULT 0.0;
	DECLARE v_tempnums INTEGER DEFAULT 0;
	
	DECLARE v_minhumi INT(11) DEFAULT 0;
	DECLARE v_maxhumi INT(11) DEFAULT 0;
	DECLARE v_avghumi DOUBLE DEFAULT 0.0;
	DECLARE v_huminums INT(11) DEFAULT 0;
	
	DECLARE v_minairp INTEGER DEFAULT 0;
	DECLARE v_maxairp INTEGER DEFAULT 0;
	DECLARE v_avgairp DOUBLE DEFAULT 0.0;
	DECLARE v_airpnums INTEGER DEFAULT 0;
	
	DECLARE v_minillu INT(11) DEFAULT 0;
	DECLARE v_maxillu INT(11) DEFAULT 0;
	DECLARE v_avgillu DOUBLE DEFAULT 0.0;
	DECLARE v_illunums INT(11) DEFAULT 0;
	
SET @BeginTime = UNIX_TIMESTAMP("2016-09-17 16:40:00"); -- 从整点开始，便于7分钟汇聚规律
WHILE @BeginTime < UNIX_TIMESTAMP(NOW()) DO
  SELECT                                                    
		 MIN(temp), MAX(temp), AVG(temp),COUNT(*)  
		INTO v_mintemp, v_maxtemp, v_avgtemp, v_tempnums FROM sensorrecord_new 
		WHERE TYPE =2 AND UNIX_TIMESTAMP(local_time) >= @BeginTime - 300 AND UNIX_TIMESTAMP(local_time) < @BeginTime;
		
		SELECT                                                    
		 MIN(humi), MAX(humi), AVG(humi),COUNT(*)  
		INTO v_minhumi, v_maxhumi, v_avghumi, v_huminums FROM sensorrecord_new 
		WHERE TYPE =2 ='temphumi' AND UNIX_TIMESTAMP(local_time) >= @BeginTime - 420 AND UNIX_TIMESTAMP(local_time) < @BeginTime;
		
		SELECT                                                    
		 MIN(hr_press), MAX(hr_press), AVG(hr_press),COUNT(*)  
		INTO v_minairp, v_maxairp, v_avgairp, v_airpnums FROM sensorrecord_new 
		WHERE TYPE =5 AND UNIX_TIMESTAMP(local_time) >= @BeginTime - 420 AND UNIX_TIMESTAMP(local_time) < @BeginTime;
		
		SELECT                                                    
		 MIN(illu), MAX(illu), AVG(illu),COUNT(*)  
		INTO v_minillu, v_maxillu, v_avgillu, v_illunums FROM sensorrecord_new 
		WHERE TYPE =4 AND UNIX_TIMESTAMP(local_time) >= @BeginTime - 420 AND UNIX_TIMESTAMP(local_time) < @BeginTime;
		
		INSERT INTO seven_mins_temp (mintemp,maxtemp,avgtemp,tempnums,minhumi,maxhumi,avghumi,huminums,
		minairp,maxairp,avgairp,airpnums,minillu,maxillu,avgillu,illunums,recordtime)
		VALUES(v_mintemp, v_maxtemp, v_avgtemp, v_tempnums,
		v_minhumi, v_maxhumi, v_avghumi, v_huminums,
		v_minairp, v_maxairp, v_avgairp, v_airpnums,
		v_minillu, v_maxillu, v_avgillu, v_illunums,
		DATE_FORMAT(FROM_UNIXTIME(@BeginTime), "%Y-%m-%d %H:%i:%S"));
  SET @BeginTime = @BeginTime + 420;  -- 7分钟的跨度相加
END WHILE;       
ENd;

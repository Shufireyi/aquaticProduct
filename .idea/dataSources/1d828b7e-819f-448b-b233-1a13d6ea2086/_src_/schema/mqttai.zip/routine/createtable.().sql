CREATE PROCEDURE createtable()
  BEGIN
	#Routine body goes here...
DROP TABLE if EXISTS incr_temp;
CREATE TABLE incr_temp
(
mintemp int ,
maxtemp int,
avgtemp double,
minhumi int,
maxhumi int,
avghumi double,
tempnums int,

minairp int,
maxairp int,
avgairp double,
airpnums int,

minillu int,
maxillu int,
avgillu double,
illunums int,

recordtime datetime
);

DROP TABLE if EXISTS incr_shuichan;
CREATE TABLE incr_shuichan
(
minorp int,
maxorp int,
avgorp double,
orpnums int,

minph int,
maxph int,
avgph double,
phnums int,

minwtrtemp int,
maxwtrtemp int,
avgwtrtemp double,
wtrtempnums int,
recordtime datetime
);

END;

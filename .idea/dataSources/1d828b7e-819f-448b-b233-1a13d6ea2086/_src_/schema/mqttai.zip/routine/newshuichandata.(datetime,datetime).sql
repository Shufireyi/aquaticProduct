CREATE PROCEDURE newshuichandata(IN firsttime DATETIME, IN lasttime DATETIME)
  BEGIN

set @histime=firsttime;
set @endtime=lasttime;
while @histime < @endtime do          #对小于对比时间的数据进行汇聚
set @ph=null,@do2=null,@water_temp=null;
select  AVG(value) into @ph			#查询固城河1的ph_1、do2_1、water_temp_1的平均值并插入新表
	from mqttai.ShuichanData 		
	where factoryid=1
	and type="ph_1"
	and time<=@histime			#数据的查询时间段为半小时
	and time>@histime-interval 30 minute;
select  AVG(value) into @do2
	from mqttai.ShuichanData 
	where factoryid=1
	and type="do2_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
select  AVG(value) into @water_temp
	from mqttai.ShuichanData 
	where factoryid=1
	and type="water_temp_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
insert into mqttai.IntegrationData(companyid,factoryid,sensorid,type,value,time)
	values(2,1,1,"do2_1",ROUND(@do2,2),@histime),
	      (2,1,2,"ph_1",ROUND(@ph,2),@histime),
	      (2,1,2,"water_temp_1",ROUND(@water_temp,2),@histime);

set @ph=null,@do2=null,@water_temp=null;
select  AVG(value) into @ph			#固城河2
	from mqttai.ShuichanData 
	where factoryid=1
	and type="ph_2"
	and time<=@histime
	and time>@histime-interval 30 minute;
select  AVG(value) into @do2
	from mqttai.ShuichanData 
	where factoryid=1
	and type="do2_2"
	and time<=@histime
	and time>@histime-interval 30 minute;
select  AVG(value) into @water_temp
	from mqttai.ShuichanData 
	where factoryid=1
	and type="water_temp_2"
	and time<=@histime
	and time>@histime-interval 30 minute;
insert into mqttai.IntegrationData(companyid,factoryid,sensorid,type,value,time)
	values(2,1,3,"do2_2",ROUND(@do2,2),@histime),
	      (2,1,4,"ph_2",ROUND(@ph,2),@histime),
	      (2,1,4,"water_temp_2",ROUND(@water_temp,2),@histime);

set @ph=null,@do2=null,@water_temp=null;
select  AVG(value) into @ph				#渔网大市场1
	from mqttai.ShuichanData 
	where factoryid=2
	and type="ph_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
select  AVG(value) into @do2
	from mqttai.ShuichanData 
	where factoryid=2
	and type="do2_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
select  AVG(value) into @water_temp
	from mqttai.ShuichanData 
	where factoryid=2
	and type="water_temp_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
insert into mqttai.IntegrationData(companyid,factoryid,sensorid,type,value,time)
	values(2,2,1,"do2_1",ROUND(@do2,2),@histime),
	      (2,2,2,"ph_1",ROUND(@ph,2),@histime),
	      (2,2,2,"water_temp_1",ROUND(@water_temp,2),@histime);

set @ph=null,@do2=null,@water_temp=null;
select  AVG(value) into @ph				#渔网大市场2
	from mqttai.ShuichanData 
	where factoryid=3
	and type="ph_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
select  AVG(value) into @do2
	from mqttai.ShuichanData 
	where factoryid=3
	and type="do2_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
select  AVG(value) into @water_temp
	from mqttai.ShuichanData 
	where factoryid=3
	and type="water_temp_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
insert into mqttai.IntegrationData(companyid,factoryid,sensorid,type,value,time)
	values(2,3,1,"do2_1",ROUND(@do2,2),@histime),
	      (2,3,2,"ph_1",ROUND(@ph,2),@histime),
	      (2,3,2,"water_temp_1",ROUND(@water_temp,2),@histime);

set @ph=null,@do2=null,@water_temp=null;
select  AVG(value) into @ph				#渔网大市场3
	from mqttai.ShuichanData 
	where factoryid=4
	and type="ph_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
select  AVG(value) into @do2
	from mqttai.ShuichanData 
	where factoryid=4
	and type="do2_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
select  AVG(value) into @water_temp
	from mqttai.ShuichanData 
	where factoryid=4
	and type="water_temp_1"
	and time<=@histime
	and time>@histime-interval 30 minute;
insert into mqttai.IntegrationData(companyid,factoryid,sensorid,type,value,time)
	values(2,4,1,"do2_1",ROUND(@do2,2),@histime),
	      (2,4,2,"ph_1",ROUND(@ph,2),@histime),
	      (2,4,2,"water_temp_1",ROUND(@water_temp,2),@histime);

set @histime=@histime+interval 30 minute;  		#对比时间+30分钟，循环执行
end while;
END;
